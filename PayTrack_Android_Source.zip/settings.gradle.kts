
rootProject.name = "PayTrack"
include(":app")
